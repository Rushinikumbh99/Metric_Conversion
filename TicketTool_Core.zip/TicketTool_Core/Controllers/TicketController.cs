﻿using Microsoft.AspNetCore.Mvc;
using TicketTool_Core.Models;

namespace TicketTool_Core.Controllers
{
    public class TicketController : Controller
    {
        private TicketToolDBContext _context;

        public TicketController(TicketToolDBContext context)
        {
            _context = context;
        }
        int UserID;
        public IActionResult Dashboard()
        {
            if (HttpContext.Session.GetString("UserID") == null)
            {
                Response.Redirect("User\\Login");
            }
            else
            {
                UserID = Convert.ToInt16(HttpContext.Session.GetString("UserID"));
                List<TicketMasterClass> TicketList = _context.TicketMaster.Where(x => x.AssignedTo == UserID).ToList();

                return View(TicketList);

            }

            return View();
        }

        public IActionResult TicketMaster()
        {
            return View();
        }

        [HttpPost]
        public IActionResult TicketMaster(TicketMasterClass TM)
        {
            if(TM!=null)
            {
                _context.Add(TM);
                _context.SaveChanges();
            }
            return View();
        }



    }
}
