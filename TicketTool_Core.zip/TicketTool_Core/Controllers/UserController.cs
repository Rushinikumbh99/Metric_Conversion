﻿using Microsoft.AspNetCore.Mvc;
using TicketTool_Core.Models;

namespace TicketTool_Core.Controllers
{
    public class UserController : Controller
    {
        private TicketToolDBContext _context;

        public UserController(TicketToolDBContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string UserName, string Password)
        {
            UsersClass UC = _context.Users.Where(x => x.Username == UserName && x.Password == Password && x.Status == 1).FirstOrDefault();
            if (UC != null)
            {
                HttpContext.Session.SetString("UserID", UC.Id.ToString());
                HttpContext.Session.SetString("FullName", UC.FirstName+" "+UC.LastName.ToString());
                Response.Redirect("Ticket\\Dashboard");
            }
            return View();
            
        }
    }
}
