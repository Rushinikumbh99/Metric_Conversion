﻿namespace TicketTool_Core.Models
{
    public class TicketMasterClass
    {
        public int ID
        {
            get; set;
        }
        public string TicketNo
        {
            get; set;
        }
        public string TicketTitle
        {
            get; set;
        }
        public string Description
        {
            get; set;
        }
        public string FirstName
        {
            get; set;
        }
        public string LastName
        {
            get; set;
        }
        public string Email
        {
            get; set;
        }
        public string Mobile
        {
            get; set;
        }
        public string CreatedOn
        {
            get; set;
        }
        public int ? AssignedTo
        {
            get; set;
        }
        public string Status
        {
            get; set;
        }
        public string ? IsCompleted
        {
            get; set;
        }
        public string ? UpdatedOn
        {
            get; set;
        }
    }
}
