﻿using Microsoft.EntityFrameworkCore;

namespace TicketTool_Core.Models
{
    public class TicketToolDBContext : DbContext
    {
        public TicketToolDBContext(DbContextOptions<TicketToolDBContext> options) : base(options)
        {

        }

        public DbSet<UsersClass> Users { get; set; }
        public DbSet<TicketMasterClass> TicketMaster { get; set; }
        
    }
}
